#! /bin/sh
exec autoreconf --install
